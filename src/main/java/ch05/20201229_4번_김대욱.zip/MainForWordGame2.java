package ch05;

public class MainForWordGame2 {
    public static void main(String[] args) {
//        WordGame2 game1 = new WordGame2();
//        game1.playGame();

        WordGame2 game2 = new WordGame2("해질녘");
        game2.playGame();
    }
}
